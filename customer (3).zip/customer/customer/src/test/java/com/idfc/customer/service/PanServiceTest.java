package com.idfc.customer.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.optimus.idfc.mule.response.VerifyPanRequest;
import com.optimus.idfc.mule.response.VerifyPanRequest.Frm;
import com.optimus.idfc.mule.response.VerifyPanRequest.HeaderFields;
import com.optimus.idfc.mule.response.VerifyPanRequest.VerifyPANReq;
import com.optimus.idfc.mule.response.VerifyPanRequest.VerifyPanReqMsgBdy;
import com.optimus.idfc.mule.response.VerifyPanRequest.VerifyPanReqMsgHdr;
import com.optimus.idfc.mule.response.VerifyPanResponse;
import com.optimus.idfc.mule.response.VerifyPanResponse.ErrorType;
import com.optimus.idfc.mule.response.VerifyPanResponse.VerifyPANResponse;
import com.optimus.idfc.mule.response.VerifyPanResponse.VerifyPanDetails;
import com.optimus.idfc.mule.response.VerifyPanResponse.VerifyPanMsgBdy;
import com.optimus.idfc.mule.response.VerifyPanResponse.VerifyPanMsgHdr;
import com.optimus.idfc.request.PanRequest;
import com.optimus.idfc.response.ErrorMessage;
import com.optimus.idfc.response.MessageResponse;
import com.optimus.idfc.response.PanMessageBody;
import com.optimus.idfc.service.IntegrationService;
import com.optimus.idfc.service.PanService;
import com.optimus.idfc.transformer.CustomerTransformer;

@ExtendWith(MockitoExtension.class)
public class PanServiceTest {

	@Mock
	private IntegrationService integrationService;

	@Mock
	private CustomerTransformer CustomerTransformer;

	@InjectMocks
	private PanService panService;

	private VerifyPanRequest getVerifyPanRequest(String panNumber) {
		VerifyPanReqMsgHdr msgHdr = VerifyPanReqMsgHdr.builder().frm(Frm.builder().id("ABC").build()).hdrFlds(
				HeaderFields.builder().cnvId("23648").msgId("23648").timestamp("2021-10-05T14:00:00.000+05:30").build())
				.build();
		VerifyPanReqMsgBdy msgBdy = VerifyPanReqMsgBdy.builder().panNumber(panNumber).customerId("").build();

		return VerifyPanRequest.builder().verifyPANReq(VerifyPANReq.builder().msgHdr(msgHdr).msgBdy(msgBdy).build())
				.build();
	}

	private VerifyPanResponse getVerifyPanResponse(String panNumber) {
		VerifyPanDetails response = VerifyPanDetails.builder().firstName("Sanjeev").panNumber(panNumber).build();

		VerifyPanMsgHdr msgHdr = VerifyPanMsgHdr.builder().rslt("OK").build();
		VerifyPanMsgBdy msgBdy = VerifyPanMsgBdy.builder().status("Success").response(response).build();
		VerifyPANResponse verifyPANResp = VerifyPANResponse.builder().msgHdr(msgHdr).msgBdy(msgBdy).build();
		return VerifyPanResponse.builder().verifyPANResp(verifyPANResp).build();
	}

	private VerifyPanResponse getVerifyPanErrorResponse(String panNumber) {

		List<ErrorType> errors = new ArrayList<VerifyPanResponse.ErrorType>();
		ErrorType errorType = ErrorType.builder().cd("123").rsn("Pan verification failed").build();
		errors.add(errorType);

		VerifyPanMsgHdr msgHdr = VerifyPanMsgHdr.builder().rslt("Error").error(errors).build();
		VerifyPanMsgBdy msgBdy = VerifyPanMsgBdy.builder().build();
		VerifyPANResponse verifyPANResp = VerifyPANResponse.builder().msgHdr(msgHdr).msgBdy(msgBdy).build();
		return VerifyPanResponse.builder().verifyPANResp(verifyPANResp).build();
	}

	@Test
	public void verifyPanTest_Success() {
		PanRequest panRequest = PanRequest.builder().leadRefId("REF_ID").panNumber("ABC123PL").build();

		Mockito.when(CustomerTransformer.prepareVerifyPanRequest(Mockito.anyObject()))
				.thenReturn(getVerifyPanRequest(panRequest.getPanNumber()));

		Mockito.when(integrationService.verifyPanDetails(Mockito.anyObject()))
				.thenReturn(getVerifyPanResponse(panRequest.getPanNumber()));

		MessageResponse<?> response2 = panService.verifyPanDetails(panRequest);

		PanMessageBody b = (PanMessageBody) response2.getMessageBody();
		assertEquals("Sanjeev", b.getFirstName());
		assertEquals(panRequest.getPanNumber(), b.getPanNumber());
	}

	@Test
	public void verifyPanTest_Failure() {
		PanRequest panRequest = PanRequest.builder().leadRefId("REF_ID").panNumber("ABC123PL").build();

		Mockito.when(CustomerTransformer.prepareVerifyPanRequest(Mockito.anyObject()))
				.thenReturn(getVerifyPanRequest(panRequest.getPanNumber()));

		Mockito.when(integrationService.verifyPanDetails(Mockito.anyObject()))
				.thenReturn(getVerifyPanErrorResponse(panRequest.getPanNumber()));

		MessageResponse<?> response2 = panService.verifyPanDetails(panRequest);

		ErrorMessage errMessage = (ErrorMessage) response2.getMessageBody();

		assertEquals("400", response2.getMessageHeader().getCode());
		assertEquals("Pan verification failed", errMessage.getErrorMessage());
	}
}
