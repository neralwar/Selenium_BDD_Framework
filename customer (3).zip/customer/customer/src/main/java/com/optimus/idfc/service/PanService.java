package com.optimus.idfc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.optimus.idfc.VerifyPanException;
import com.optimus.idfc.mule.response.VerifyPanRequest;
import com.optimus.idfc.mule.response.VerifyPanResponse;
import com.optimus.idfc.request.PanRequest;
import com.optimus.idfc.response.ErrorMessage;
import com.optimus.idfc.response.ErrorMessage.ApiError;
import com.optimus.idfc.transformer.CustomerTransformer;

import io.github.resilience4j.retry.annotation.Retry;

@Service
public class PanService {

	@Autowired
	private IntegrationService integrationService;

	// @CircuitBreaker(maxAttempts = 3, openTimeout=15000l, resetTimeout=30000l)
	// @CircuitBreaker(name = "ca-customer-service", fallbackMethod =
	// "panServiceMethod")
	@Retry(name = "customerservice", fallbackMethod = "panServiceMethod")
	public VerifyPanResponse verifyPanDetails(PanRequest panRequest) {
		VerifyPanRequest verifyPanRequest = CustomerTransformer.prepareVerifyPanRequest(panRequest);
		return integrationService.verifyPanDetails(verifyPanRequest);
	}

	public VerifyPanResponse panServiceMethod(Exception e) {
		List<ApiError> errors = new ArrayList<ErrorMessage.ApiError>();
		errors.add(CustomerTransformer.prepareApiError("CUST-EXP-0001", HttpStatus.NOT_FOUND.value(),
				"CustomerException", "PAN Verification Failed", "PAN Service is down."));
		throw new VerifyPanException(HttpStatus.NOT_FOUND, errors);
	}
}
