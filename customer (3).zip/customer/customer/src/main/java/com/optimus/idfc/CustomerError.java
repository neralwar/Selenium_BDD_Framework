package com.optimus.idfc;

public enum CustomerError {
	CUST_EXP_0001("CUST-EXP-0001", "A database error has occurred.", "a"),
	CUST_EXP_0002("CUST-EXP-0002", "This user already exists.", "b");

	private final String errorCode;
	private final String message;
	private final String detail;

	private CustomerError(String errorCode, String message, String detail) {
		this.errorCode = errorCode;
		this.message = message;
		this.detail = detail;
	}

	public String getDetail() {
		return detail;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return errorCode + ": " + message + " " + detail;
	}
}
