package com.optimus.idfc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.optimus.idfc.mule.response.VerifyPanRequest;
import com.optimus.idfc.mule.response.VerifyPanResponse;

@Component
public class IntegrationService {

	@Value("${mule.url.verify.pan}")
	private String muleVerifyPanUrl;

	@Autowired
	private RestTemplate restTemplate;

	public VerifyPanResponse verifyPanDetails(VerifyPanRequest verifyPanRequest) {
		System.out.println("retry...");
		return restTemplate.postForObject(muleVerifyPanUrl.concat("/nsdl/verifyPan"), verifyPanRequest,
				VerifyPanResponse.class);
	}
	
	
}
