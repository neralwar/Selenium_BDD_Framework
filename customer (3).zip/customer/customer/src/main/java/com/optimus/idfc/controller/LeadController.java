package com.optimus.idfc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.ImmutableMap;
import com.optimus.idfc.entity.LeadEntity;
import com.optimus.idfc.request.LeadRequest;
import com.optimus.idfc.response.LeadMessageBody;
import com.optimus.idfc.response.MessageHeader;
import com.optimus.idfc.response.MessageResponse;
import com.optimus.idfc.service.LeadService;

import io.jaegertracing.internal.JaegerTracer;
import io.opentracing.Span;

@RestController
@RequestMapping(value = "/lead")
public class LeadController {

	@Autowired
	LeadService leadService;

	@Autowired
	JaegerTracer tracer;
	
	@PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MessageResponse> createLead(@RequestBody LeadRequest request) {

		// Create a span
	    Span span = tracer.buildSpan("create lead").start();
	    
		LeadEntity lead = leadService.saveLead(request);
		MessageResponse response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("200").build())
				.messageBody(LeadMessageBody.builder().leadRefId(Long.toString(lead.getId())).firstName(lead.getFirstName())
						.build())
				.build();
		span.setTag("http.status_code", 200);
		span.log(ImmutableMap.of("event", "create-success", "value", request));
		span.finish();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
