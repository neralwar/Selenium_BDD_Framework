package com.optimus.idfc.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.optimus.idfc.entity.LeadEntity;

@Repository
public interface LeadRepository extends CrudRepository<LeadEntity, Long> {

}
