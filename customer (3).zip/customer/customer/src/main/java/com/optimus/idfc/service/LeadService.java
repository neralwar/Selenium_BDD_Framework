package com.optimus.idfc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optimus.idfc.entity.LeadEntity;
import com.optimus.idfc.repository.LeadRepository;
import com.optimus.idfc.request.LeadRequest;

@Service
public class LeadService {

	@Autowired
	private LeadRepository leadRepository;

	public LeadEntity saveLead(LeadRequest request) {
		LeadEntity lead = LeadEntity.builder().id(1L).firstName(request.getFirstName()).build();
		return leadRepository.save(lead);

	}

}
