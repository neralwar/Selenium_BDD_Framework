package com.optimus.idfc.stub.controller;

import com.optimus.idfc.mule.response.VerifyPanRequest;
import com.optimus.idfc.mule.response.VerifyPanResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class VerifyPanSetup {

	private VerifyPanRequest request;

	private VerifyPanResponse response;
}
