package com.optimus.idfc.stub.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optimus.idfc.mule.response.VerifyPanRequest;
import com.optimus.idfc.mule.response.VerifyPanResponse;
import com.optimus.idfc.request.LeadRequest;

@RestController
@RequestMapping("/stub/mule")
@Profile("stub-test")
public class LeadStubController {

	private Map<String, MuleMessageResponse> leadList = new HashMap<String, MuleMessageResponse>();
	private Map<String, VerifyPanResponse> panList = new HashMap<String, VerifyPanResponse>();

	private MuleMessageResponse getMuleMessageResponse(String panNumber) {
		return leadList.get(panNumber);
	}

	private VerifyPanResponse getVerifyPanResponse(String panNumber) {
		return panList.get(panNumber);
	}

	@PostMapping("/lead/create/register")
	public void createLeadRegister(@RequestBody LeadSetup leadSetup) {
		leadList.put(leadSetup.getRequest().getPanNumber(), leadSetup.getResponse());
	}

	@PostMapping("/lead/create")
	public MuleMessageResponse createLead(@RequestBody LeadRequest leadRequest) {
		return getMuleMessageResponse(leadRequest.getPanNumber());
	}

	@PostMapping("/nsdl/verifyPan/register")
	public void verifyManRegister(@RequestBody VerifyPanSetup verifyPanSetup) {
		panList.put(verifyPanSetup.getRequest().getVerifyPANReq().getMsgBdy().getPanNumber(),
				verifyPanSetup.getResponse());
	}

	@PostMapping("/nsdl/verifyPan")
	public VerifyPanResponse verifyMan(@RequestBody VerifyPanRequest panRequest) {
		return getVerifyPanResponse(panRequest.getVerifyPANReq().getMsgBdy().getPanNumber());
	}
}
