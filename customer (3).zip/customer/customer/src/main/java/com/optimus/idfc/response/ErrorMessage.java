package com.optimus.idfc.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Data
@Builder
public class ErrorMessage {

	private List<ApiError> errors;

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class ApiError {
		private ErrorMessageHeader msg_hdr;
		private ErrorMessageBody msg_body;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class ErrorMessageHeader {
		private String errorCode;
		private int status;
		private String type;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class ErrorMessageBody {
		private String message;
		private String detail;
	}
}
