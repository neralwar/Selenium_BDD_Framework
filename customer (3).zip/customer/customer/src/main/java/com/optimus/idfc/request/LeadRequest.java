package com.optimus.idfc.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class LeadRequest {

	private String firstName;

	private String middleName;

	private String lastName;

	private String panNumber;
}
