package com.optimus.idfc.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * This class provides the data time format utility.
 *
 */
@Component
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DateFormatUtility {

	private static final String DDMMYYYY = "ddMMyyyy";
	private static final String YYYYMMDD_T_HHMMSS = "yyyy-MM-dd'T'HH:mm:ss";
	private static final String DATE_FORMAT_WITH_MICRO = "yyyy-MM-dd'T'HH:mm:ss:SSS";
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	private static final String AUTH_DATE = "yyyy-MM-dd'T'HH:mm:ss";
	private static final String DATE_FORMAT_WITH_MICRO_DOT = "yyyy-MM-dd'T'HH:mm:ss.SSS";

	/**
	 * Returns the date with format "ddMMyyyy"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateFormatddmmyyyy(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(DDMMYYYY));
	}

	/**
	 * Returns the date with format "yyyy-MM-dd'T'HH:mm:ss"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateTimeFormat(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(YYYYMMDD_T_HHMMSS));
	}

	/**
	 * Returns the date with format "yyyy-MM-dd'T'HH:mm:ss:SSS"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateTimeMicroFormat(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAT_WITH_MICRO));
	}

	/**
	 * Returns the date with format "yyyy-MM-dd'T'HH:mm:ss"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateTimewithGMT(LocalDateTime localDateTime) {
		String localDate = localDateTime.format(DateTimeFormatter.ofPattern(YYYYMMDD_T_HHMMSS));
		return localDate + "+05:30";
	}

	/**
	 * Returns the date with format "yyyy-MM-dd"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String simpleDate(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAT));

	}

	/**
	 * Returns the date with format "yyyy-MM-dd'T'HH:mm:ss"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateTimeForAuth(LocalDateTime localDateTime) {
		String localDate = localDateTime.format(DateTimeFormatter.ofPattern(AUTH_DATE));
		return localDate + "-05:00";
	}

	/**
	 * Returns the date with format "yyyy-MM-dd'T'HH:mm:ss.SSS"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateTimeMicroDotFormat(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAT_WITH_MICRO_DOT));
	}

	/**
	 * Returns the date with format "yyyy-MM-dd'T'HH:mm:ss.SSS"
	 * 
	 * @param localDateTime
	 * @return
	 */
	public static String dateTimeMicroDotFormat2(LocalDateTime localDateTime) {
		String localDate = localDateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAT_WITH_MICRO_DOT));
		return localDate + "+05:30";
	}
}
