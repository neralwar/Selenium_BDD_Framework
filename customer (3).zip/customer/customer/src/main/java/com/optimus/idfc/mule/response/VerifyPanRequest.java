package com.optimus.idfc.mule.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@ToString
public class VerifyPanRequest {

	private VerifyPANReq verifyPANReq;

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPANReq {
		private VerifyPanReqMsgHdr msgHdr;
		private VerifyPanReqMsgBdy msgBdy;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPanReqMsgHdr {
		private Frm frm;
		private HeaderFields hdrFlds;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPanReqMsgBdy {
		private String panNumber;
		private String customerId;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class Frm {
		private String id;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class HeaderFields {
		private String msgId;
		private String cnvId;
		private String timestamp;
	}
}
