package com.optimus.idfc;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * It provides the configured rest template
 *
 */
@Configuration
@Component
public class RestTemplateConfig {

	@Bean
	RestTemplate getRestTempate() {
		return new RestTemplate();
	}

}
