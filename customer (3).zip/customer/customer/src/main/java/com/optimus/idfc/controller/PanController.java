package com.optimus.idfc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optimus.idfc.VerifyPanException;
import com.optimus.idfc.mule.response.VerifyPanResponse;
import com.optimus.idfc.request.PanRequest;
import com.optimus.idfc.response.ErrorMessage;
import com.optimus.idfc.response.ErrorMessage.ApiError;
import com.optimus.idfc.response.MessageHeader;
import com.optimus.idfc.response.MessageResponse;
import com.optimus.idfc.response.PanMessageBody;
import com.optimus.idfc.service.PanService;
import com.optimus.idfc.transformer.CustomerTransformer;

@RestController
@RequestMapping("/nsdl")
public class PanController {

	@Autowired
	private PanService panService;

	@SuppressWarnings("static-access")
	@GetMapping(value = "/verifyPan", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getPanDetails(@RequestBody PanRequest panCardRequest) {

		VerifyPanResponse response = panService.verifyPanDetails(panCardRequest);
		String result = response.getVerifyPANResp().getMsgHdr().getRslt();
		if (result.equalsIgnoreCase("OK")) {
			MessageResponse<?> msgResponse = MessageResponse.builder()
					.messageHeader(MessageHeader.builder().code(Integer.toString(HttpStatus.OK.value())).build())
					.messageBody(
							PanMessageBody.fromVerifyPanDetails(response.getVerifyPANResp().getMsgBdy().getResponse()))
					.build();
			return new ResponseEntity<MessageResponse<?>>(msgResponse, HttpStatus.OK);
		} else {
			List<ApiError> errors = new ArrayList<ErrorMessage.ApiError>();
			response.getVerifyPANResp().getMsgHdr().getError().forEach(error -> {
				errors.add(CustomerTransformer.prepareApiError("CUST-EXP-0001", HttpStatus.BAD_REQUEST.value(),
						"CustomerException", error.getCd(), error.getRsn()));
			});

			throw new VerifyPanException(HttpStatus.BAD_REQUEST, errors);
		}
	}
}
