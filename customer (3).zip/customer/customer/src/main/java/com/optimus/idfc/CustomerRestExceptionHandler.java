package com.optimus.idfc;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.optimus.idfc.response.ErrorMessage;

@ControllerAdvice
public class CustomerRestExceptionHandler extends ResponseEntityExceptionHandler {

	@SuppressWarnings("rawtypes")
	@ExceptionHandler({ VerifyPanException.class })
	public ResponseEntity<ErrorMessage> customerPanException(VerifyPanException ex) {

		ErrorMessage errorMessage = ErrorMessage.builder().errors(ex.getErrors()).build();
		return new ResponseEntity<ErrorMessage>(errorMessage, ex.getCode());
	}
}
