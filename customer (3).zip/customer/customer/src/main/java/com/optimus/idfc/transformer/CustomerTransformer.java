package com.optimus.idfc.transformer;

import java.time.LocalDateTime;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Component;

import com.optimus.idfc.mule.response.VerifyPanRequest;
import com.optimus.idfc.mule.response.VerifyPanRequest.Frm;
import com.optimus.idfc.mule.response.VerifyPanRequest.HeaderFields;
import com.optimus.idfc.mule.response.VerifyPanRequest.VerifyPANReq;
import com.optimus.idfc.mule.response.VerifyPanRequest.VerifyPanReqMsgBdy;
import com.optimus.idfc.mule.response.VerifyPanRequest.VerifyPanReqMsgHdr;
import com.optimus.idfc.request.PanRequest;
import com.optimus.idfc.response.ErrorMessage.ApiError;
import com.optimus.idfc.response.ErrorMessage.ErrorMessageBody;
import com.optimus.idfc.response.ErrorMessage.ErrorMessageHeader;
import com.optimus.idfc.util.DateFormatUtility;

@Component
public class CustomerTransformer {

	public static VerifyPanRequest prepareVerifyPanRequest(PanRequest panRequest) {
		String uniqueId = RandomStringUtils.randomNumeric(10);
		String timestamp = DateFormatUtility.dateTimeFormat(LocalDateTime.now().plusMinutes(0));

		VerifyPanReqMsgHdr msgHdr = VerifyPanReqMsgHdr.builder().frm(Frm.builder().id("ABC").build())
				.hdrFlds(HeaderFields.builder().cnvId(uniqueId).msgId(uniqueId).timestamp(timestamp).build()).build();
		VerifyPanReqMsgBdy msgBdy = VerifyPanReqMsgBdy.builder().panNumber(panRequest.getPanNumber()).customerId("")
				.build();

		return VerifyPanRequest.builder().verifyPANReq(VerifyPANReq.builder().msgHdr(msgHdr).msgBdy(msgBdy).build())
				.build();
	}

	public static ApiError prepareApiError(String errorCode, int status, String type, String message,
			String detail) {
		ErrorMessageHeader header = ErrorMessageHeader.builder().errorCode(errorCode).status(status).type(type).build();
		ErrorMessageBody body = ErrorMessageBody.builder().message(message).detail(detail).build();
		return ApiError.builder().msg_hdr(header).msg_body(body).build();
	}
}
