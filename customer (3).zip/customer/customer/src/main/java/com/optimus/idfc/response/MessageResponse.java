package com.optimus.idfc.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class MessageResponse<T> {

	@JsonProperty(value = "msg_hdr")
	private MessageHeader messageHeader;
	
	@JsonProperty(value = "msg_body")
	private T messageBody;
}
