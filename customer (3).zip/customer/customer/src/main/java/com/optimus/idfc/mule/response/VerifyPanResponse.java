package com.optimus.idfc.mule.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class VerifyPanResponse {

	private VerifyPANResponse verifyPANResp;

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPANResponse {
		private VerifyPanMsgHdr msgHdr;
		private VerifyPanMsgBdy msgBdy;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPanMsgHdr {
		private String rslt;
		private List<ErrorType> error;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPanMsgBdy {
		private String status;
		private VerifyPanDetails response;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyPanDetails {
		private String panNumber;
		private String firstName;
		private String middleName;
		private String lastName;
		private String panTitle;
		private String panStatus;
		private String returnCode;
		private String lastUpdatedDate;
		private String namePrintedOnPANCard;
		private String typeOfHolder;
		private String adharStaus;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class ErrorType {
		private String cd;
		private String rsn;
	}
}