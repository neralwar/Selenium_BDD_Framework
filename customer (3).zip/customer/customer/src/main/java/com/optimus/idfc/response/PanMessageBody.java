package com.optimus.idfc.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.optimus.idfc.mule.response.VerifyPanResponse.VerifyPanDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PanMessageBody {

	private String panStatus;
	private String firstName;
	private String middlenName;
	private String lastName;
	private String panNumber;
	private String aadharSeedingStatus;

	public static PanMessageBody fromVerifyPanDetails(VerifyPanDetails verifyPanDetails) {
		return PanMessageBody.builder().panStatus(verifyPanDetails.getPanStatus())
				.firstName(verifyPanDetails.getFirstName()).middlenName(verifyPanDetails.getMiddleName())
				.lastName(verifyPanDetails.getLastName()).panNumber(verifyPanDetails.getPanNumber())
				.aadharSeedingStatus(verifyPanDetails.getAdharStaus()).build();
	}
}
