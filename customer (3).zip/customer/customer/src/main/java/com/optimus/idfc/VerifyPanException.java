package com.optimus.idfc;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.optimus.idfc.response.ErrorMessage.ApiError;

import lombok.Data;

@Data
public class VerifyPanException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private HttpStatus code;
	private List<ApiError> errors;

	public VerifyPanException(HttpStatus code, List<ApiError> errors) {
		this.code = code;
		this.errors = errors;
	}
}
