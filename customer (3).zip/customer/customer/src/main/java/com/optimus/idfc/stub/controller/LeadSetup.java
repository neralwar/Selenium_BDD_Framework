package com.optimus.idfc.stub.controller;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class LeadSetup {

	private MuleLeadRequest request;

	private MuleMessageResponse response;
}
